const mysql = require('mysql');

const connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: 'AreBhaiOp@12',
    connectTimeout: 20000,
    database: 'userdb'
});
connection.connect(function(error){
    if (error){
        throw error;
    }else{
        console.log('Mysql Database is connected.')
    }
})

module.exports =connection;
